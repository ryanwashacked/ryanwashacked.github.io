	var ROOT_ACTIVITY_ID = "http://www.taolin.co.uk/program/ilead/course/how-to-manage-change/learning-object/leadership-journal",
	    tincan = new TinCan({
	        url: window.location.href,
	        activity: {
	            id: ROOT_ACTIVITY_ID
	        }
	    }),
	    TCActive = false,
	    actorName = "",
	    actorEmail = "",
	    gameId = "",
	    HighScoresActivityProfile = null,
	    HighScoresArray;

	var lrs;
	try {
	    lrs = new TinCan.LRS({
	        endpoint: "https://cloud.scorm.com/tc/JYFUW991B4/",
	        username: "chgm3Ilb9S33LDPYkDg",
	        password: "5Xuy9z0SHCOkmTCG4r8",
	        allowFail: false
	    });
	} catch (ex) {
	    console.log("Failed to setup LRS object: " + ex);
	    // TODO: do something with error, can't communicate with LRS
	}


	$(document).ready(function() {

	    var leActor;
	    var learnerScore;
	    var retrievedStatements;
	    var actorNameField = $("#actorNameField");
	    var statementsArray = [];
	    var testArray = [];
	    var journalEntries = $("#journalEntries");
		var courseCategories = [];	    
		var leFilters = $("#leFilters");	    
	    if (typeof tincan !== "undefined" && tincan.actor !== null) {
	        leActor = tincan.actor;
	        actorName = leActor.name.split(/\s+/).slice(0, 1).join(" ");
	        actorEmail = leActor.mbox;
	        console.log(tincan);
	    } else {
	        actorName = "Ryan Dervakos";
	        actorName = actorName.split(/\s+/).slice(0, 1).join(" ");
	        actorEmail = "mailto:ryandi@theartoflearn.com"
	    }

	    var initStatement = new TinCan.Statement({
	        actor: {
	            mbox: actorEmail
	        },
	        verb: {
	            id: "http://adlnet.gov/expapi/verbs/initialized",
	            display: {
	                "en-US": "initialized"
	            }
	        },
	        object: {
	            id: "http://www.taolin.co.uk/program/ilead/course/how-to-manage-change/learning-object/leadership-journal"
	        },
	    });

	    var endStatement = new TinCan.Statement({
	        actor: {
	            mbox: actorEmail
	        },
	        verb: {
	            id: "http://adlnet.gov/expapi/verbs/completed",
	            display: {
	                "en-US": "completed"
	            }
	        },
	        object: {
	            id: "http://www.taolin.co.uk/program/ilead/course/how-to-manage-change/learning-object/leadership-journal"
	        },
	        result: {
	            completion: true,
	            success: true,
	            score: {
	                scaled: 0.0,
	                raw: 0,
	                min: 0,
	                max: 0
	            },
	            duration: "PT0H0M2S"
	        }
	    });

	    signalStatement(initStatement);
	    actorNameField.html("");
	    actorNameField.append(actorName);
	    retrieveStatements();

	    function signalStatement(statement) {
	        console.log(statement);
	        tincan.sendStatement(statement, function() {
	            console.log("statement TC");
	        });
	        lrs.saveStatement(
	            statement, {
	                callback: function(err, xhr) {
	                    if (err !== null) {
	                        if (xhr !== null) {
	                            console.log("Failed to save statement: " + xhr.responseText + " (" + xhr.status + ")");
	                            // TODO: do something with error, didn't save statement
	                            return;
	                        }

	                        console.log("Failed to save statement: " + err);
	                        // TODO: do something with error, didn't save statement
	                        return;
	                    }

	                    console.log("Statement saved");
	                    // TOOO: do something with success (possibly ignore)
	                }
	            }
	        );
	    }

	    function retrieveStatements() {
	        lrs.queryStatements({
	            params: {
	                verb: new TinCan.Verb({
	                    id: "http://adlnet.gov/expapi/verbs/reflected"
	                }),
	                agent: new TinCan.Agent({
	                    mbox: actorEmail
	                }),
	            },
	            callback: function(err, sr) {
	                if (err !== null) {
	                    console.log("Failed to query statements: " + err);
	                    // TODO: do something with error, didn't get statements
	                    return;
	                }

	                if (sr.more !== null) {
	                    // TODO: additional page(s) of statements should be fetched
	                }

	                $.each(sr.statements, function(k, v) {
	                    console.log(k);
	                    if (testArray[v.target.id] == null) {
	                        testArray[v.target.id] = v.target.id;
	                        statementsArray[k] = {
	                            id: v.target.id,
	                            stored: v.stored,
	                            course: getCourseFromTcURI(v.target.id),
	                            lo: getLoFromTcUri(v.target.id),
	                            reflection: v.context.extensions[v.target.id + "/userInput"]
	                        };
	                    }


	                });
	                generateCourseCategories();
	                console.log(courseCategories);
	                populateStatementsUI();
	                var filters = courseCategories.join();
	                console.log(filters);
	                journalEntries.mixItUp({
						load: {
							filter: filters
						},
						controls: {
							toggleFilterButtons: false
						}
					});
	                // TODO: do something with statements in sr.statements
	            }
	        });
	    }

	    function populateStatementsUI() {
	        console.log(statementsArray);
	        for (var i = 0; i <= statementsArray.length; i++) {
	            if (statementsArray[i] != null) {
	                // console.log(statementsArray[i].course);
	                journalEntries.append(journalEntryMarkup(statementsArray[i].course, statementsArray[i].lo, statementsArray[i].reflection, statementsArray[i].stored));
	            }
	        }

	    }

	    function generateCourseCategories(){
	    	var testArrayo = [];
	    	var testArrayyo2 = [];
	    	var count = 0;
	        for (var i = statementsArray.length - 1; i >= 0; i--) {
	            if (statementsArray[i] != null) {
	                // console.log(statementsArray[i].course);
	                if(statementsArray[i].course != null){
	                	if(testArrayyo2[statementsArray[i].course] == null){
	                	testArrayyo2[statementsArray[i].course] = statementsArray[i].course;
	                	courseCategories[count] = "."+statementsArray[i].course;
	                	count = count + 1;	 
	                	}
	                }               	
	            }
	        }
	        generateFilterButtons();
	        // console.log(testArrayyo2);	    	
	    }

	    function generateFilterButtons(){
	    	for (var i = courseCategories.length - 1; i >= 0; i--) {
	    		var coursePres = courseCategories[i].split('-').join(' ').replace('.', '');
	    		leFilters.append("<button class='filter' data-filter='"+courseCategories[i]+"' style=' text-transform: capitalize;'>"+coursePres+"</button>");
	    	}
	    }

	    function journalEntryMarkup(course, lo, reflection, time) {
	        if (course != null && lo != null && reflection != null) {
	            var html = "<div class='mix "+course+"'><p><b>Course: " + course + "</b></p><p>Module: " + lo + "</p><p style='background: #d6d6d6;padding: 10px;'>Reflection: <span class='leReflection'>" + reflection + "</span></p></div>";
	        } else {
	            html = "";
	        }
	        return html;
	    }

	    function getIdFromTcURI(uri) {

	        var returnMe = uri.split("/");
	        return returnMe[8];
	    }

	    function getCourseFromTcURI(uri) {
	        var returnMe = uri.split("/");
	        return returnMe[6];
	    }

	    function getLoFromTcUri(uri) {
	        var returnMe = uri.split("/");
	        if (returnMe[returnMe.length - 2] != 'learning-object') {
	            return returnMe[returnMe.length - 2] + " " + returnMe[returnMe.length - 1];
	        } else {
	            return returnMe[returnMe.length - 1];
	        }

	    }
	});